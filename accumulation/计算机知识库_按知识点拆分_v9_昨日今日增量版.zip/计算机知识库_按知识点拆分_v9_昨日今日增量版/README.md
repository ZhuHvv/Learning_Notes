# 计算机知识库（v9 昨日今日增量版）

本知识库按“一条知识点一个文件”的方式组织，覆盖 LLM、Agent、Python、Go、数据库、Redis、Kafka、RabbitMQ、后端部署与网络等内容。

本版新增 Go 接口方法集与 gRPC 注册、Redis 过期删除、RabbitMQ 延时队列、TTL 检测、惰性队列和 Federation。纯报错分析类内容未作为本次新增知识点沉淀。

建议入口：

- `00_总体索引.md`
- `00_覆盖清单.md`
- `00_理解推进轨迹.md`
- `00_质量检查报告.md`
