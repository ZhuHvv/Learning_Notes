# RabbitMQ 延时队列：TTL、死信交换机与延时插件

> 所属分类：Message Queue / RabbitMQ  
> 修订版本：v9 昨日今日增量版  
> 质量要求：本文件只解释本知识点，不复用其他知识点的原理段；示例尽量给出代码、伪代码、命令或配置。

## 1. 总体性概念

RabbitMQ 原生队列不是专门的定时任务系统，但可以用两种常见方式实现延时消息：

1. **TTL + 死信交换机（DLX）**：消息先进入延时队列，过期后成为死信，再被路由到真正的业务队列。
2. **延时消息插件**：使用 `x-delayed-message` exchange，把延时时间作为消息属性交给插件调度。

你讨论的方案一就是 TTL + 死信队列：消息到达队列 TTL 或消息 TTL 后，被转发到死信交换机，再进入特定业务队列供消费者消费。

## 2. 原理性解释

### 2.1 TTL + DLX 的核心链路

RabbitMQ 中消息过期后不一定直接丢弃。如果队列配置了死信交换机，过期消息会被重新发布到 DLX，并按 dead-letter routing key 路由到目标队列。

```text
Producer
  ↓ publish
Delay Exchange
  ↓
Delay Queue（设置 TTL + x-dead-letter-exchange）
  ↓ 消息过期
Dead Letter Exchange
  ↓
Business Queue
  ↓
Consumer
```

这是一种“借道死信机制”的延时实现：延时队列不做业务消费，只负责暂存消息；业务队列只接收已经到期的消息。

### 2.2 队列 TTL 与消息 TTL

RabbitMQ 支持两类 TTL：

- **队列级 TTL**：队列中所有消息使用同一个过期时间，例如所有订单 30 分钟后关闭。
- **消息级 TTL**：每条消息单独设置 expiration，例如 A 消息 5 秒后处理，B 消息 30 秒后处理。

队列级 TTL 更适合固定延时；消息级 TTL 更灵活，但会引出“不同消息过期时间如何检测”的问题。

### 2.3 为什么不同 TTL 容易出现队头阻塞

普通队列本质上是 FIFO。即使第二条消息先过期，如果第一条消息还没过期，RabbitMQ 在很多场景下也不会越过第一条消息把第二条先投递到死信队列。这会导致延时不准确：

```text
队列头部：MsgA TTL=60s
第二条：  MsgB TTL=5s

5s 后 MsgB 理论上过期，但 MsgA 仍在头部，MsgB 可能无法及时死信转发。
```

所以 TTL + DLX 更适合“同一延时等级一个队列”，例如：

```text
order.delay.5s.q
order.delay.30s.q
order.delay.30m.q
```

如果需要大量不同延时，延时插件或外部调度系统通常更合适。

## 3. 机制流程

```text
创建业务交换机 order.biz.ex
  ↓
创建业务队列 order.close.q 并绑定 close routing key
  ↓
创建延时队列 order.delay.30m.q
  ├─ x-message-ttl = 1800000
  ├─ x-dead-letter-exchange = order.biz.ex
  └─ x-dead-letter-routing-key = order.close
  ↓
生产者把消息发入延时队列
  ↓
TTL 到期后消息进入 DLX
  ↓
业务消费者从 order.close.q 消费
```

## 4. 类比理解

延时队列像“定时投递箱”：信先放到一个不会马上派送的箱子里，到时间后被转交给真正的快递分拣中心。死信交换机不是坏消息专用，也可以被借来做延时转发。

## 5. 应用举例 / 代码或伪代码

### 5.1 订单超时关闭

```python
# 业务队列
channel.exchange_declare("order.biz.ex", exchange_type="direct", durable=True)
channel.queue_declare("order.close.q", durable=True)
channel.queue_bind("order.close.q", "order.biz.ex", routing_key="order.close")

# 延时队列：30 分钟后转发到业务交换机
args = {
    "x-message-ttl": 30 * 60 * 1000,
    "x-dead-letter-exchange": "order.biz.ex",
    "x-dead-letter-routing-key": "order.close",
}
channel.queue_declare("order.delay.30m.q", durable=True, arguments=args)

# 下单后发送延时消息
channel.basic_publish(
    exchange="",
    routing_key="order.delay.30m.q",
    body=json.dumps({"order_id": 1001}),
    properties=pika.BasicProperties(delivery_mode=2),
)
```

消费者处理时要二次确认订单状态：

```python
def close_order(msg):
    order = db.get_order(msg["order_id"])
    if order.status == "PAID":
        return
    if order.status == "CREATED":
        db.update_status(order.id, "CLOSED")
```

### 5.2 多延时等级设计

```text
order.delay.5s.q    → DLX → order.retry.q
order.delay.1m.q    → DLX → order.retry.q
order.delay.30m.q   → DLX → order.close.q
```

这种设计避免大量不同 TTL 混在同一个 FIFO 队列里造成队头阻塞。

## 6. 你在讨论中的理解推进

- 起点：你总结“利用死信队列，消息到达队列 TTL 或消息 TTL 后进入死信队列，被特定消费者消费”。
- 修正：严格说消息过期后先进入死信交换机，再路由到死信队列；消费者消费的是最终绑定到 DLX 的队列。
- 深化：你进一步追问不同 TTL 是否需要逐个检测，推动出队头阻塞、延时插件和分级延时队列的区别。

## 7. 常见误区与排查思路

- **误区 1：死信队列只能处理失败消息。** 过期、拒绝、队列满等都可能进入 DLX，延时队列正是利用过期死信。
- **误区 2：消息 TTL 不同也能精准按时间顺序触发。** 普通 FIFO 队列容易受队头消息影响。
- **误区 3：延时队列等于定时任务系统。** MQ 延时适合消息触发，不适合复杂日历规则和大规模精确定时。

## 8. 关联知识点

- `084_RabbitMQ_TTL_过期检测、队列头阻塞与延时消息.md`
- `077_RabbitMQ：vhost、exchange、queue、binding.md`
- `070_Redis_过期删除：惰性删除、定期删除与内存淘汰.md`

## 9. 复习检查问题

- TTL + DLX 实现延时队列的完整路径是什么？
- 队列 TTL 和消息 TTL 有什么区别？
- 为什么不同 TTL 混用可能导致延时不准？
- 订单超时关闭为什么必须二次查订单状态？
