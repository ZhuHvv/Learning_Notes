# RabbitMQ TTL 过期检测、队列头阻塞与延时消息

> 所属分类：Message Queue / RabbitMQ  
> 修订版本：v9 昨日今日增量版  
> 质量要求：本文件只解释本知识点，不复用其他知识点的原理段；示例尽量给出代码、伪代码、命令或配置。

## 1. 总体性概念

你问过一个非常关键的问题：如果 RabbitMQ 队列中每条延时消息 TTL 都不同，是否每条消息都需要单独检测？是不是每条消息都有一个独立计时器？

答案是：**通常不是每条消息一个独立系统计时器。RabbitMQ 会在队列结构、消息位置和相关调度点上判断消息是否过期。普通队列的 FIFO 特性还会带来队列头阻塞问题。**

## 2. 原理性解释

### 2.1 过期判断不等于独立计时器

每条消息确实可以有自己的过期时间，但这不意味着 broker 为每条消息创建一个操作系统计时器。更常见的方式是：

- 消息写入时记录过期时间；
- 队列准备投递或扫描某些位置时检查是否到期；
- 到期后将消息丢弃或 dead-letter；
- 对普通 FIFO 队列，队头消息的状态会显著影响后续消息。

这和 Redis 惰性删除有相似处：都不是简单地“到点自动触发一个独立回调”。

### 2.2 队头阻塞是延时不准的核心原因

考虑一个普通队列：

```text
front
  MsgA：TTL 60s
  MsgB：TTL 5s
  MsgC：TTL 10s
back
```

5 秒后，MsgB 已经过期，但它排在 MsgA 后面。如果 RabbitMQ 不越过 MsgA 检查后面的消息，MsgB 就不能马上进入死信流程。直到 MsgA 到期或被处理，后面的消息才有机会被检查。

这就是为什么“每条消息不同 TTL + 普通 FIFO 队列”不适合做精确延时。

### 2.3 固定延时队列为什么更稳定

如果一个队列中所有消息都是 30 分钟 TTL，那么 FIFO 顺序和过期顺序基本一致：先进入队列的消息通常也先过期。这样 broker 只需要关注队头，就能得到相对稳定的延时行为。

```text
order.delay.30m.q
  Msg1 enter 10:00 → expire 10:30
  Msg2 enter 10:01 → expire 10:31
  Msg3 enter 10:02 → expire 10:32
```

过期顺序和入队顺序一致，队头阻塞影响很小。

### 2.4 延时插件为什么可以处理不同延时

`x-delayed-message` 插件的思路不同：消息不是先进入普通 FIFO 队列等待 TTL，而是由 delayed exchange 根据延迟时间管理，到期后再路由到目标队列。

```text
Producer → Delayed Exchange（按 x-delay 调度）→ Business Queue → Consumer
```

它更像“调度器”，而 TTL + DLX 更像“让消息在队列里等到过期”。

## 3. 机制流程

### 3.1 TTL + DLX 过期流程

```text
消息进入延时队列
  ↓
队列记录消息 TTL / expireAt
  ↓
broker 在投递、队头检查或内部维护过程中发现消息过期
  ↓
若配置 DLX：将消息转发到死信交换机
  ↓
DLX 按 routing key 转发到业务队列
```

### 3.2 不同 TTL 的风险流程

```text
MsgA TTL=60s 在队头
MsgB TTL=5s 在后面
  ↓
5s 后 MsgB 逻辑过期
  ↓
但队头 MsgA 未过期
  ↓
MsgB 可能无法及时被 dead-letter
  ↓
实际处理时间晚于预期
```

## 4. 类比理解

普通队列像排队窗口。第二个人的预约时间更早到了，但第一个人还占着窗口，工作人员不会跳过第一个人去处理第二个人。延时插件则像按预约时间排序的叫号系统，到点的人会被叫到业务窗口。

## 5. 应用举例 / 代码或伪代码

### 5.1 不推荐：大量不同 TTL 混在一个普通队列

```python
# A 延时 60s，B 延时 5s，都进同一个 delay.q
publish("delay.q", "A", expiration="60000")
publish("delay.q", "B", expiration="5000")
# B 可能不会在 5s 时准时进入 DLX
```

### 5.2 推荐：按延时等级拆队列

```python
DELAY_LEVELS = {
    "5s": "order.delay.5s.q",
    "30s": "order.delay.30s.q",
    "30m": "order.delay.30m.q",
}

def publish_delay(order_id, level):
    q = DELAY_LEVELS[level]
    channel.basic_publish(exchange="", routing_key=q, body=str(order_id))
```

### 5.3 推荐：插件方式

```python
channel.exchange_declare(
    exchange="order.delay.ex",
    exchange_type="x-delayed-message",
    arguments={"x-delayed-type": "direct"},
    durable=True,
)

channel.basic_publish(
    exchange="order.delay.ex",
    routing_key="order.close",
    body=json.dumps({"order_id": 1001}),
    properties=pika.BasicProperties(headers={"x-delay": 30 * 60 * 1000}),
)
```

## 6. 你在讨论中的理解推进

- 起点：你觉得“每条不同 TTL 消息都单独检测”成本太高，猜测 RabbitMQ 一定不是每条消息一个计时器。
- 修正：这个判断方向是对的；过期通常依赖消息过期时间记录、队列检查和调度点，而不是海量独立计时器。
- 深化：你进一步类比 Redis 惰性删除，形成了“过期检测往往是延迟判断，而不是绝对准时触发”的理解。

## 7. 常见误区与排查思路

- **误区 1：TTL 到期等于马上进入死信队列。** 普通队列可能受到队头阻塞影响。
- **误区 2：每条消息 TTL 不同也适合普通延时队列。** 延迟精度可能很差。
- **误区 3：延时队列适合所有定时任务。** 高精度、大规模、多时间点任务更适合专门调度系统。

排查延时不准时，优先看：

```text
同一 delay queue 是否混合了大量不同 TTL？
队头是否存在长 TTL 消息？
是否配置 DLX 和 dead-letter routing key？
是否需要改用 x-delayed-message 插件？
```

## 8. 关联知识点

- `083_RabbitMQ_延时队列：TTL、死信交换机与延时插件.md`
- `070_Redis_过期删除：惰性删除、定期删除与内存淘汰.md`
- `085_RabbitMQ_惰性队列：磁盘优先与消费定位.md`

## 9. 复习检查问题

- 为什么“每条消息一个计时器”不适合大规模消息系统？
- 队头阻塞如何影响不同 TTL 消息的延时准确性？
- 固定延时队列为什么比混合 TTL 队列更稳定？
- 延时插件和 TTL + DLX 的机制差异是什么？
