# Message Queue

本目录整理 Kafka、RabbitMQ、消息分发、延时队列、惰性队列、Federation、重试和最终一致性。

本目录包含 16 个知识点文件。每个文件都按统一学习结构组织：概念、原理、机制流程、类比、代码/伪代码、理解推进、误区、关联知识点和复习问题。

## 文件列表

- [消息队列的核心概念：生产者、队列、消费者、消息分发](071_消息队列的核心概念：生产者、队列、消费者、消息分发.md)
- [流量削峰、异步解耦与最终一致性](072_流量削峰、异步解耦与最终一致性.md)
- [Kafka：KRaft、Broker、Topic、Partition、Replica](073_Kafka：KRaft、Broker、Topic、Partition、Replica.md)
- [Kafka Consumer Group 与 Offset](074_Kafka_Consumer_Group_与_Offset.md)
- [Kafka Leader Follower ISR 与故障选举](075_Kafka_Leader_Follower_ISR_与故障选举.md)
- [Kafka 重试机制、Retry Topic 与死信队列](076_Kafka_重试机制、Retry_Topic_与死信队列.md)
- [Kafka Key、分区策略与热分区](077_Kafka_Key、分区策略与热分区.md)
- [Kafka 消息分发、多消费者语义与幂等处理](078_Kafka_消息分发、多消费者语义与幂等处理.md)
- [Kafka Docker Compose 与 volume 路径问题](079_Kafka_Docker_Compose_与_volume_路径问题.md)
- [RabbitMQ：vhost、exchange、queue、binding](080_RabbitMQ：vhost、exchange、queue、binding.md)
- [Routing Key 与 Binding Key](081_Routing_Key_与_Binding_Key.md)
- [Kafka vs RabbitMQ：事件流与业务路由](082_Kafka_vs_RabbitMQ：事件流与业务路由.md)
- [RabbitMQ 延时队列：TTL、死信交换机与延时插件](083_RabbitMQ_延时队列：TTL、死信交换机与延时插件.md)
- [RabbitMQ TTL 过期检测、队列头阻塞与延时消息](084_RabbitMQ_TTL_过期检测、队列头阻塞与延时消息.md)
- [RabbitMQ 惰性队列：磁盘优先与消费定位](085_RabbitMQ_惰性队列：磁盘优先与消费定位.md)
- [RabbitMQ Federation：联邦交换机与联邦队列](086_RabbitMQ_Federation：联邦交换机与联邦队列.md)
