# Database / Redis

本目录整理数据库、Redis 数据结构、过期删除、缓存、限流、复制和高可用。

本目录包含 14 个知识点文件。每个文件都按统一学习结构组织：概念、原理、机制流程、类比、代码/伪代码、理解推进、误区、关联知识点和复习问题。

## 文件列表

- [数据库选型：SQL、MongoDB、Redis、向量库的分工](057_数据库选型：SQL、MongoDB、Redis、向量库的分工.md)
- [SQLite：轻量级本地关系数据库](058_SQLite：轻量级本地关系数据库.md)
- [B+树索引、复合索引与最左前缀](059_B+树索引、复合索引与最左前缀.md)
- [MySQL / PostgreSQL：事务型关系数据库](060_MySQL___PostgreSQL：事务型关系数据库.md)
- [MongoDB：文档型数据库与灵活 Schema](061_MongoDB：文档型数据库与灵活_Schema.md)
- [Redis 基本数据类型与时间存储](062_Redis_基本数据类型与时间存储.md)
- [Redis 特殊类型：HyperLogLog、Bitmap、Geo、Stream](063_Redis_特殊类型：HyperLogLog、Bitmap、Geo、Stream.md)
- [Redis 会话状态、临时映射与资源池](064_Redis_会话状态、临时映射与资源池.md)
- [Redis 限流与 Lua 原子操作](065_Redis_限流与_Lua_原子操作.md)
- [Redis 复制：PSYNC、FULLRESYNC、RDB 与 backlog](066_Redis_复制：PSYNC、FULLRESYNC、RDB_与_backlog.md)
- [Redis IO Threads 与事件循环](067_Redis_IO_Threads_与事件循环.md)
- [Redis Cluster：槽、CLUSTER SLOTS、PFAIL FAIL 与故障转移](068_Redis_Cluster：槽、CLUSTER_SLOTS、PFAIL_FAIL_与故障转移.md)
- [Redis Sentinel 与 Cluster 的区别](069_Redis_Sentinel_与_Cluster_的区别.md)
- [Redis 过期删除：惰性删除、定期删除与内存淘汰](070_Redis_过期删除：惰性删除、定期删除与内存淘汰.md)
