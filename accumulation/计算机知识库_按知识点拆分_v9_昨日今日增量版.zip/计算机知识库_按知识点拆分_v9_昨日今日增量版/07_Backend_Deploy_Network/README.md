# Backend / Deploy / Network

本目录整理 REST/RPC/gRPC、服务注册心跳、代理、容器、监控、流式协议和安全边界。

本目录包含 10 个知识点文件。每个文件都按统一学习结构组织：概念、原理、机制流程、类比、代码/伪代码、理解推进、误区、关联知识点和复习问题。

## 文件列表

- [RESTful API、持久化服务与微服务](087_RESTful_API、持久化服务与微服务.md)
- [RPC 与 gRPC：服务间调用](088_RPC_与_gRPC：服务间调用.md)
- [正向代理与反向代理](089_正向代理与反向代理.md)
- [Docker、Docker Compose 与 Windows 常见问题](090_Docker、Docker_Compose_与_Windows_常见问题.md)
- [Kubernetes、服务发现与弹性部署](091_Kubernetes、服务发现与弹性部署.md)
- [Prometheus、Grafana、OpenTelemetry 与日志](092_Prometheus、Grafana、OpenTelemetry_与日志.md)
- [HTTP Streaming、SSE、WebSocket 与 gRPC Streaming](093_HTTP_Streaming、SSE、WebSocket_与_gRPC_Streaming.md)
- [沙箱、权限与工具执行安全](094_沙箱、权限与工具执行安全.md)
- [RPC 动态代理与字节码生成](095_RPC_动态代理与字节码生成.md)
- [RPC 心跳、服务注册与可用性检测](096_RPC_心跳、服务注册与可用性检测.md)
