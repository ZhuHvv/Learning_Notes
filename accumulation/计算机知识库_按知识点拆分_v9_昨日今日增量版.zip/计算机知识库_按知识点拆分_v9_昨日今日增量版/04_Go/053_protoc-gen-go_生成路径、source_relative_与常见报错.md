# protoc-gen-go 生成路径、source_relative 与常见报错

> 所属分类：Go / Gin / Runtime  
> 修订版本：v9 昨日今日增量版  
> 质量要求：本文件只解释本知识点，不复用其他知识点的原理段；示例尽量给出代码、伪代码、命令或配置。

## 1. 总体性概念

`protoc` 负责读取 `.proto` 文件，`protoc-gen-go` 负责生成 Go 代码。生成文件的“包身份”和“落盘路径”由两类配置共同决定：

- `.proto` 中的 `option go_package`：说明 Go import path 和 package name。
- 命令行中的 `--go_out` / `--go_opt=paths=...`：说明文件实际生成到哪里。

你遇到的典型现象是：

```text
生成的 pb.go 文件路径为：rpc-learn/proto/rpc-learn/proto
main.go 中 import msg "rpc-learn/proto" 为什么不行？
```

本质原因是：**生成目录和 Go import path 对应的实际目录不一致。**

## 2. 原理性解释

### 2.1 默认路径模式容易生成嵌套目录

当你写：

```proto
option go_package = "rpc-learn/proto;msg";
```

又执行类似：

```bash
protoc --go_out=. proto/msg.proto
```

在默认 `paths=import` 模式下，插件会按照 Go import path 创建目录，因此可能得到：

```text
./rpc-learn/proto/msg.pb.go
```

如果你是在 `proto` 目录中执行命令，或者 `--go_out` 指向了 `proto`，就可能进一步嵌套成：

```text
proto/rpc-learn/proto/msg.pb.go
```

这时 `import "rpc-learn/proto"` 会去 module 根目录下找 `./proto`，但文件实际在 `./proto/rpc-learn/proto`，自然导入失败。

### 2.2 `paths=source_relative` 的作用

`source_relative` 的意思是：生成文件路径跟随 `.proto` 源文件路径，而不是跟随 `go_package` 的 import path 创建目录。

```bash
protoc --go_out=. --go_opt=paths=source_relative proto/msg.proto
```

如果源文件是：

```text
proto/msg.proto
```

生成文件就是：

```text
proto/msg.pb.go
```

这通常更适合小型 module 项目，因为目录结构直观。

### 2.3 `--go_out` 只控制输出根目录

```bash
--go_out=.
```

表示输出到当前目录下，但具体是否追加 `rpc-learn/proto` 这样的路径，要看 `paths` 模式。

```text
--go_out=. + paths=import
  → 按 go_package import path 创建目录

--go_out=. + paths=source_relative
  → 按 proto 源文件相对路径创建目录
```

## 3. 机制流程

```text
protoc 读取 proto/msg.proto
  ↓
protoc-gen-go 读取 go_package = "rpc-learn/proto;msg"
  ↓
检查命令行 paths 模式
  ├─ paths=import：按 rpc-learn/proto 创建输出目录
  └─ paths=source_relative：按 proto/msg.proto 的源路径生成 proto/msg.pb.go
  ↓
Go import 再按 go.mod module + 目录寻找包
```

最稳定的排查思路是：

```text
第一步：看 go.mod module 是什么
第二步：看 main.go import 写什么
第三步：看生成的 .pb.go 实际在哪个目录
第四步：看 .pb.go 顶部 package 名是否一致
```

## 4. 类比理解

`go_package` 像包裹上的“收件地址”，`--go_out` 像快递站的“起始投递点”，`paths` 像“按收件地址分拣”还是“按原货架位置摆放”。地址写对但包裹被放到另一层仓库，你去正确地址仍然找不到。

## 5. 应用举例 / 代码或伪代码

### 5.1 推荐命令：保持源目录结构

目录：

```text
rpc-learn/
  go.mod                    // module rpc-learn
  main.go
  proto/
    msg.proto
    services.proto
```

`msg.proto`：

```proto
option go_package = "rpc-learn/proto;msg";
```

生成：

```bash
protoc   --go_out=.   --go_opt=paths=source_relative   proto/msg.proto proto/services.proto
```

结果：

```text
proto/msg.pb.go
proto/services.pb.go
```

`main.go`：

```go
import msg "rpc-learn/proto"
```

### 5.2 生成后路径错误的修复

如果你生成出了：

```text
proto/rpc-learn/proto/msg.pb.go
```

不要只改 `import` 去迁就错误路径。优先修正生成命令：

```bash
rm -rf proto/rpc-learn
protoc --go_out=. --go_opt=paths=source_relative proto/msg.proto
```

### 5.3 常见报错对照表

| 报错/现象 | 核心原因 | 处理方式 |
|---|---|---|
| unable to determine Go import path | 缺少 `go_package` | 在 proto 中写 `option go_package` |
| import `rpc-learn/proto` 找不到 | 生成文件不在 `./proto` | 检查 `--go_out` 和 `paths` |
| inconsistent names | 同一 import path 下包名不一致 | 统一 `;package` 或拆目录 |
| command-line-arguments is not a main package | 被运行文件不是 `package main` | 改为 `package main` 并提供 `func main` |

## 6. 你在讨论中的理解推进

- 起点：你看到生成路径变成 `proto/rpc-learn/proto`，直觉上觉得 `import rpc-learn/proto` 应该能用。
- 修正：Go import 看的是 module 根路径下的真实目录，而不是 `go_package` 字符串本身。
- 推进：你开始意识到 `go_package` 负责包身份，`--go_out` 和 `paths` 负责落盘路径。
- 深化：你最终把问题归结为“option 的写法没懂，Go package 管理也没懂”，这正好对应本文件的两个核心变量：包身份与文件位置。

## 7. 常见误区与排查思路

- **误区 1：`go_package` 决定文件一定生成到对应目录。** 实际还受 `paths` 控制。
- **误区 2：生成路径错了就改 import。** 通常应该先修生成命令。
- **误区 3：在 proto 目录下运行命令和在项目根运行命令效果一样。** 相对路径会受到当前工作目录影响。
- **排查建议：** 先固定从 module 根目录执行 protoc，减少路径混乱。

## 8. 关联知识点

- Go Module、package 与 import 路径
- Protobuf option go_package 与 Go 代码生成
- gRPC proto 文件组织、package 一致性与 pb.go 导入
- Docker、Docker Compose 与 Windows 常见问题

## 9. 复习检查问题

- `paths=import` 和 `paths=source_relative` 的区别是什么？
- 为什么 `go_package` 写对了，生成路径仍然可能不符合预期？
- 生成到 `proto/rpc-learn/proto` 时，为什么 `import "rpc-learn/proto"` 不会自动找到它？
- 排查 protoc 生成路径问题时，应该按什么顺序检查？
