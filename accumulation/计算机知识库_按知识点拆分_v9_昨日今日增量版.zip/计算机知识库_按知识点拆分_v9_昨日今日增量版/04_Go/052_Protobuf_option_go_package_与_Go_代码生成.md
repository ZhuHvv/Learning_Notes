# Protobuf option go_package 与 Go 代码生成

> 所属分类：Go / Gin / Runtime  
> 修订版本：v9 昨日今日增量版  
> 质量要求：本文件只解释本知识点，不复用其他知识点的原理段；示例尽量给出代码、伪代码、命令或配置。

## 1. 总体性概念

`.proto` 文件里的 `option xxx = ...;` 是给具体语言插件或 protobuf 编译器使用的配置。它不一定改变消息结构本身，而是影响**代码生成方式**。

在 Go 里最关键的是：

```proto
option go_package = "rpc-learn/proto;msg";
```

它包含两层含义：

- `rpc-learn/proto`：生成 Go 代码应该属于哪个 Go import path。
- `msg`：生成的 `.pb.go` 文件使用哪个 Go package name。

这和 `.proto` 里的：

```proto
package msg;
```

不是一回事。`package msg;` 是 protobuf 的命名空间；`option go_package` 是 Go 语言生成代码的包路径配置。

## 2. 原理性解释

### 2.1 为什么 protoc-gen-go 必须知道 Go import path

你遇到的报错：

```text
protoc-gen-go: unable to determine Go import path for "msg.proto"

Please specify either:
  • a "go_package" option in the .proto source file, or
  • a "M" argument on the command line.
```

核心意思是：`protoc-gen-go` 需要知道生成的 Go 文件未来应该被怎样 import。没有 `go_package` 时，它不知道这个 `.proto` 对应哪个 Go 包，因此拒绝生成。

### 2.2 `package` 与 `go_package` 的分工

```proto
syntax = "proto3";

package msg;
option go_package = "rpc-learn/proto;msg";

message HelloRequest {
  string name = 1;
}
```

这里：

- `package msg;`：影响 protobuf 层的全名，例如 `msg.HelloRequest`。
- `go_package = "rpc-learn/proto;msg";`：影响 Go 层的导入路径和源码包名。

如果只写 `package msg;`，Go 插件仍然可能不知道 Go import path；如果只写 `go_package`，Go 代码能生成，但 protobuf 命名空间也要根据工程需求合理组织。

### 2.3 `go_package` 的两种常见形式

```proto
option go_package = "rpc-learn/proto";
```

只写 import path，Go package name 通常由最后一级路径推导，例如 `proto`。

```proto
option go_package = "rpc-learn/proto;msg";
```

显式指定 import path 和 Go package name。`;` 后面的名字会出现在 `.pb.go` 顶部：

```go
package msg
```

### 2.4 `option go_package="./msg;msg"` 的含义

你问过：

```proto
option go_package = "./msg;msg";
```

含义是：

- Go import path 写成相对路径 `./msg`。
- Go package name 写成 `msg`。

这种写法能表达“生成到当前相对目录下的 msg 包”，但在 module 工程中不推荐作为长期方案，因为 Go module 更强调稳定的 module import path，例如：

```proto
option go_package = "rpc-learn/msg;msg";
```

## 3. 机制流程

```text
读取 msg.proto
  ↓
protoc 把文件交给 protoc-gen-go
  ↓
protoc-gen-go 读取 option go_package
  ↓
确定 Go import path 与 package name
  ↓
生成 msg.pb.go
  ↓
Go 编译器再按 go.mod + import path 编译使用
```

注意：`go_package` 告诉插件“生成文件属于哪个 Go 包”，但最终文件落在哪个目录，还会受到 `--go_out` 和 `--go_opt=paths=...` 的影响。

## 4. 类比理解

`.proto package` 像“身份证上的籍贯”，表示 protobuf 类型属于哪个命名空间；`go_package` 像“公司通讯录地址”，告诉 Go 编译器以后应该从哪个地址找到这组生成代码。

## 5. 应用举例 / 代码或伪代码

### 5.1 推荐写法：module 内统一生成到 proto 目录

`go.mod`：

```go
module rpc-learn
```

`proto/msg.proto`：

```proto
syntax = "proto3";

package msg;
option go_package = "rpc-learn/proto;msg";

message HelloRequest {
  string name = 1;
}
```

生成命令：

```bash
protoc --go_out=. --go_opt=paths=source_relative proto/msg.proto
```

生成后：

```text
proto/msg.pb.go  // package msg
```

`main.go`：

```go
import msg "rpc-learn/proto"
```

### 5.2 不推荐长期使用的相对 go_package

```proto
option go_package = "./msg;msg";
```

这种写法容易让你误以为 import 也应该写相对路径。Go module 项目里更稳的是把 import path 写成 `module path + 子目录`。

### 5.3 命令行 M 参数的替代方案

不在 `.proto` 中写 `go_package` 时，也可以在命令中指定映射：

```bash
protoc   --go_out=.   --go_opt=Mmsg.proto=rpc-learn/proto   msg.proto
```

但工程上更推荐把 `go_package` 固化进 `.proto`，这样所有人生成代码时行为一致。

## 6. 你在讨论中的理解推进

- 起点：你看到 `option xxx`，想知道它在 `.proto` 中到底控制什么。
- 修正：`option` 是给代码生成器、语言插件或 protobuf 工具链使用的元配置，不等同于业务字段。
- 推进：你追问 `go_package="./msg;msg"`，开始区分 import path 与 package name。
- 深化：你后来结合 `go.mod module rpc-learn` 继续追问，说明已经把 protobuf 生成配置和 Go module 包管理联系起来了。

## 7. 常见误区与排查思路

- **误区 1：`.proto package` 就能替代 `go_package`。** Go 插件仍然需要 Go import path。
- **误区 2：`;msg` 是导入路径。** 分号后是 Go package name，不是目录路径。
- **误区 3：`go_package` 写对后一定能 import。** 还要看生成文件实际落在哪个目录。
- **排查：报 unable to determine Go import path。** 优先检查 `.proto` 是否写了 `option go_package`。

## 8. 关联知识点

- Go Module、package 与 import 路径
- protoc-gen-go 生成路径、source_relative 与常见报错
- gRPC proto 文件组织、package 一致性与 pb.go 导入
- RPC 与 gRPC：服务间调用

## 9. 复习检查问题

- `.proto package` 和 `option go_package` 分别解决什么问题？
- `go_package="rpc-learn/proto;msg"` 中分号前后分别是什么？
- 为什么 `protoc-gen-go` 不愿意在缺少 `go_package` 时生成代码？
- 为什么相对路径 `./msg;msg` 不适合作为长期工程写法？
