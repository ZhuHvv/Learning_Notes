# gRPC proto 文件组织、package 一致性与 pb.go 导入

> 所属分类：Go / Gin / Runtime  
> 修订版本：v9 昨日今日增量版  
> 质量要求：本文件只解释本知识点，不复用其他知识点的原理段；示例尽量给出代码、伪代码、命令或配置。

## 1. 总体性概念

在 gRPC 或 RPC 项目中，`.proto` 文件通常同时定义：

- 消息结构：`message Request { ... }`
- 服务接口：`service Greeter { rpc SayHello(...) returns (...); }`
- 生成代码所在包：`option go_package = ...`

你今天遇到的 `msg.proto` 和 `services.proto` 问题，本质是多 proto 文件组织时的包一致性问题：**如果多个 proto 文件要生成到同一个 Go 目录，它们的 Go package name 必须一致。**

## 2. 原理性解释

### 2.1 msg.proto 与 services.proto 的常见组织

一种常见做法是把消息和服务拆开：

```text
proto/
  msg.proto       // message 请求/响应结构
  services.proto  // service RPC 接口
```

如果它们都要生成到 `rpc-learn/proto` 这个 Go 包，应该统一写：

```proto
option go_package = "rpc-learn/proto;msg";
```

这样生成的 `.pb.go` 文件都属于：

```go
package msg
```

`main.go` 中统一导入：

```go
import msg "rpc-learn/proto"
```

### 2.2 什么时候拆成多个 Go 包

如果你希望消息和服务分开维护，也可以拆目录：

```text
proto/
  msg/msg.proto
  services/services.proto
```

对应：

```proto
// proto/msg/msg.proto
option go_package = "rpc-learn/proto/msg;msg";

// proto/services/services.proto
option go_package = "rpc-learn/proto/services;services";
```

但这会让服务文件引用消息时需要 import proto 文件，并在生成后的 Go 代码里形成跨包引用，复杂度更高。小型学习项目通常先放同一个 Go 包更简单。

### 2.3 `import msg "rpc-learn/msg"` 为什么可能不行

你问过：

```proto
option go_package = "rpc-learn/msg;msg";
```

然后在 `main.go` 中写：

```go
import msg "rpc-learn/msg"
```

理论上这组配置是匹配的，但前提是生成文件实际位于 module 根目录下的：

```text
msg/*.pb.go
```

如果实际生成在：

```text
proto/rpc-learn/msg/*.pb.go
```

或者仍然在：

```text
proto/*.pb.go
```

那么导入 `rpc-learn/msg` 就不成立。Go import 不看你“想把它当成什么包”，只看真实目录。

## 3. 机制流程

```text
设计 proto 文件组织
  ↓
决定是否同一个 Go 包
  ├─ 同包：多个 proto 统一 go_package = "rpc-learn/proto;msg"
  └─ 分包：不同目录 + 不同 go_package
  ↓
用 protoc 生成 pb.go / grpc.pb.go
  ↓
检查生成目录和 package 名
  ↓
在 main.go 或业务代码中按目录 import
```

gRPC 还会多一步：如果使用 `protoc-gen-go-grpc`，会生成服务接口、客户端 stub、服务端注册函数。这些生成代码本质上就是 RPC 调用链中的“生成式代理”。

## 4. 类比理解

`msg.proto` 和 `services.proto` 像一本接口文档里的“数据结构章”和“接口方法章”。如果最后要装订成同一本 Go 包，它们封面上的 Go 包名必须一样；如果你把它们装订成两本书，就要明确每本书的目录地址和相互引用关系。

## 5. 应用举例 / 代码或伪代码

### 5.1 同包组织：适合学习项目

`proto/msg.proto`：

```proto
syntax = "proto3";
package msg;
option go_package = "rpc-learn/proto;msg";

message HelloRequest {
  string name = 1;
}

message HelloReply {
  string message = 1;
}
```

`proto/services.proto`：

```proto
syntax = "proto3";
package msg;
option go_package = "rpc-learn/proto;msg";

service Greeter {
  rpc SayHello(HelloRequest) returns (HelloReply);
}
```

生成：

```bash
protoc   --go_out=. --go_opt=paths=source_relative   --go-grpc_out=. --go-grpc_opt=paths=source_relative   proto/msg.proto proto/services.proto
```

使用：

```go
import msg "rpc-learn/proto"
```

### 5.2 分包组织：适合大型项目

```text
rpc-learn/
  proto/msg/msg.proto
  proto/service/greeter.proto
```

这种做法要求 `greeter.proto` 显式 import 消息 proto：

```proto
import "proto/msg/msg.proto";
```

并在不同语言生成代码时处理跨包引用。它更清晰，但学习成本也更高。

### 5.3 pb.go 与 grpc.pb.go 分工

```text
msg.pb.go
  └─ 主要包含 message 结构体、字段访问方法、序列化相关元信息

services_grpc.pb.go
  └─ 主要包含 client interface、server interface、RegisterXxxServer 等 gRPC 代码
```

这和 RPC 调用链对应：

```text
client stub 调用方法
  ↓
序列化 request message
  ↓
网络传输
  ↓
server skeleton 解包并调用真实服务
```

## 6. 你在讨论中的理解推进

- 起点：你把两个 proto 文件的 `go_package` 写得不一致，触发 inconsistent names 报错。
- 修正：同一个 Go import path 下，多个生成文件必须 package name 一致。
- 推进：你尝试统一为 `option go_package="rpc-learn/proto;msg"`，但又遇到生成目录嵌套问题。
- 深化：你开始把 proto 文件组织、生成命令、Go module import 三者放在一起判断，而不是只盯着某一行 option。

## 7. 常见误区与排查思路

- **误区 1：文件名不同就可以不同 package。** Go 看目录，不看 proto 文件名。
- **误区 2：service 文件一定要单独 package。** 学习项目里 message 和 service 放同一包更省心。
- **误区 3：`go_package="rpc-learn/msg;msg"` 后 import 一定成功。** 还要保证生成文件真的在 `./msg`。
- **排查：** 打开 `.pb.go` 顶部，看 `package xxx`；再看文件所在目录是否和 import path 对上。

## 8. 关联知识点

- Go Module、package 与 import 路径
- Protobuf option go_package 与 Go 代码生成
- protoc-gen-go 生成路径、source_relative 与常见报错
- RPC 动态代理与字节码生成
- RPC 与 gRPC：服务间调用

## 9. 复习检查问题

- 为什么两个 proto 文件生成到同一 Go import path 时必须同包名？
- `msg.pb.go` 和 `services_grpc.pb.go` 的职责有什么区别？
- 同包组织和分包组织分别适合什么场景？
- 为什么 `go_package`、生成目录、`main.go import` 三者必须一起看？
