# Go / Gin / 服务端工程

本目录整理 Go 服务端开发、并发、Gin、Context、gRPC、Protobuf 和接口机制。

本目录包含 21 个知识点文件。每个文件都按统一学习结构组织：概念、原理、机制流程、类比、代码/伪代码、理解推进、误区、关联知识点和复习问题。

## 文件列表

- [Go 后端开发技术栈总览](036_Go_后端开发技术栈总览.md)
- [Gin Handler 闭包与依赖注入](037_Gin_Handler_闭包与依赖注入.md)
- [Gin BasicAuth、Middleware 与 Session Cookie](038_Gin_BasicAuth、Middleware_与_Session_Cookie.md)
- [Go Context：取消、超时与值传递](039_Go_Context：取消、超时与值传递.md)
- [Go GC：三色标记与混合写屏障](040_Go_GC：三色标记与混合写屏障.md)
- [逃逸分析、闭包与内存泄露](041_逃逸分析、闭包与内存泄露.md)
- [Go 内存三级缓存：mcache、mcentral、mheap、span](042_Go_内存三级缓存：mcache、mcentral、mheap、span.md)
- [GoFrame g.Meta 与声明式路由绑定](043_GoFrame_g.Meta_与声明式路由绑定.md)
- [Go SSE：text event-stream 与流式响应](044_Go_SSE：text_event-stream_与流式响应.md)
- [Eino：组件化 RAG / Agent 编排](045_Eino：组件化_RAG___Agent_编排.md)
- [Go error、panic 与 recover](046_Go_error、panic_与_recover.md)
- [Goroutine 数量、调度与性能边界](047_Goroutine_数量、调度与性能边界.md)
- [Channel 关闭、只读通道与 select 读就绪](048_Channel_关闭、只读通道与_select_读就绪.md)
- [sync.Mutex Lock、TryLock 与锁模型](049_sync.Mutex_Lock、TryLock_与锁模型.md)
- [Go 异步机制：goroutine、channel、select 与 Context](050_Go_异步机制：goroutine、channel、select_与_Context.md)
- [Go Module、package 与 import 路径](051_Go_Module、package_与_import_路径.md)
- [Protobuf option go package 与 Go 代码生成](052_Protobuf_option_go_package_与_Go_代码生成.md)
- [protoc-gen-go 生成路径、source relative 与常见报错](053_protoc-gen-go_生成路径、source_relative_与常见报错.md)
- [gRPC proto 文件组织、package 一致性与 pb.go 导入](054_gRPC_proto_文件组织、package_一致性与_pb.go_导入.md)
- [Go 接口实现、方法集与指针接收器](055_Go_接口实现、方法集与指针接收器.md)
- [gRPC RegisterServer、UnimplementedServer 与接口实现](056_gRPC_RegisterServer、UnimplementedServer_与接口实现.md)
